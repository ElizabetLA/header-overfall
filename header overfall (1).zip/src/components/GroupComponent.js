import styles from "./GroupComponent.module.css";

const GroupComponent = () => {
  return (
    <div className={styles.rectangleParent}>
      <div className={styles.componentChild} />
      <button className={styles.componentItem} />
      <div className={styles.requestContact}>request contact</div>
      <div className={styles.homeParent}>
        <button className={styles.home}>HOMe</button>
        <button className={styles.home}>How it works</button>
        <button className={styles.home}>Blog</button>
        <button className={styles.home}>About us</button>
      </div>
      <button className={styles.vectorParent}>
        <img className={styles.vectorIcon} alt="" src="/vector.svg" />
        <img className={styles.groupChild} alt="" src="/ellipse-136.svg" />
        <img className={styles.groupItem} alt="" src="/ellipse-130.svg" />
        <img className={styles.groupInner} alt="" src="/ellipse-131.svg" />
      </button>
      <div className={styles.offfferwallParent}>
        <div className={styles.offfferwall}>{`offfferwall `}</div>
        <div className={styles.monetization}>monetization</div>
      </div>
    </div>
  );
};

export default GroupComponent;
